## Summary

- Describe the purpose of this change.

## Changes

- List the most relevant implementation details.

## Validation

- [ ] Project opens in Godot 4.x
- [ ] Main menu still runs (`Play`/`Quit`)
- [ ] Updated docs/contracts when needed

## Checklist

- [ ] Scope is focused and modular
- [ ] No secrets or credentials added
- [ ] Ready for review
